import { useDashboardController } from '../../controllers/useDashboardController.js';
import { SimpleBarChart } from '../components/SimpleBarChart.jsx';

export function DashboardView() {
  const { stats, charts, loading, error } = useDashboardController();

  const attendancePresent = (charts?.attendance_trends ?? []).map((d) => ({
    label: d.label,
    value: d.present,
  }));
  const feeBars = charts?.fee_collection ?? [];
  const passBars = charts?.pass_rates ?? [];

  return (
    <>
      <div className="page-header">
        <h2>Dashboard</h2>
      </div>
      {error ? <div className="alert error">{error}</div> : null}
      {loading ? (
        <p>Loading stats…</p>
      ) : (
        <>
          <div className="grid-stats">
            <div className="stat-card">
              <span>Students</span>
              <strong>{stats?.students ?? 0}</strong>
            </div>
            <div className="stat-card">
              <span>Teachers</span>
              <strong>{stats?.teachers ?? 0}</strong>
            </div>
            <div className="stat-card">
              <span>Classes</span>
              <strong>{stats?.classes ?? 0}</strong>
            </div>
            <div className="stat-card">
              <span>Open fees</span>
              <strong>{stats?.open_fees ?? 0}</strong>
            </div>
            <div className="stat-card">
              <span>Attendance today</span>
              <strong>{stats?.attendance_marked_today ?? 0}</strong>
            </div>
            <div className="stat-card">
              <span>Grades recorded</span>
              <strong>{stats?.grades_recorded ?? 0}</strong>
            </div>
          </div>

          <div className="chart-grid" style={{ marginTop: '1.25rem' }}>
            <div className="card">
              <SimpleBarChart title="Attendance trend (present, 7 days)" items={attendancePresent} />
            </div>
            <div className="card">
              <SimpleBarChart title="Fee collection (6 months)" items={feeBars} />
            </div>
            <div className="card">
              <SimpleBarChart title="Pass rate % (recent exams, ≥50%)" items={passBars} />
            </div>
          </div>
        </>
      )}
    </>
  );
}
