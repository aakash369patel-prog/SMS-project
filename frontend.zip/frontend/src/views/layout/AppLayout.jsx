import { NavLink, Outlet } from 'react-router-dom';
import { useAuthController } from '../../controllers/AuthController.jsx';
import { usePermissions } from '../../controllers/usePermissions.js';
import { STAFF_NAV_LINKS } from '../../config/navigation.js';

export function AppLayout() {
  const { user, logout } = useAuthController();
  const { can } = usePermissions();
  const links = STAFF_NAV_LINKS.filter((link) => can(link.permission));

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <h1>School Management System</h1>
        <nav>
          {links.map((link) => (
            <NavLink key={link.to} to={link.to} className={({ isActive }) => (isActive ? 'active' : undefined)}>
              {link.label}
            </NavLink>
          ))}
        </nav>
      </aside>
      <div className="main">
        <div className="topbar">
          <span>
            {user?.name} ({user?.role})
          </span>
          <button type="button" className="btn secondary" onClick={() => logout()}>
            Logout
          </button>
        </div>
        <Outlet />
      </div>
    </div>
  );
}
