<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class FeeTypeResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'code' => $this->code,
            'amount' => (float) $this->amount,
            'academic_year' => $this->academic_year,
            'description' => $this->description,
            'created_at' => $this->created_at?->toISOString(),
        ];
    }
}
